<?php

add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_styles', PHP_INT_MAX);
function enqueue_child_theme_styles() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
  wp_enqueue_script( 'custom-js', get_stylesheet_directory_uri().'/custom.js', '', '', true );
}

// Allow SVG uploads
function allow_svgimg_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'allow_svgimg_types');

add_action( 'widgets_init', 'my_new_sidebar' );
function my_new_sidebar() {
  $args = array(
    'name'          => 'Second Sidebar',
    'id'            => 'second-sidebar',
    'description'   => 'This is your brand new sidebar.',
    'class'         => '',
    'before_widget' => '<li id="%1$s" class="widget %2$s">',
    'after_widget'  => '</li>',
    'before_title'  => '<h2 class="widgettitle">',
    'after_title'   => '</h2>' 
  );
  register_sidebar( $args );
}

add_filter( 'woocommerce_get_price_html', 'wpa83367_price_html', 100, 2 );
function wpa83367_price_html( $price, $product ){
    $prices = explode(" ",strip_tags($price));
    $p=[];
    $average = 0;
    foreach ($prices as $k => $v) {
      $v = str_replace(',', '', $v);
      $p[] = floatval($v);
    }
    if(count($p)>1){
      $average = number_format((float)((($p[0]-$p[1])/$p[0])*100), 2, '.', '');
      $price = $price.'<br />You save - <span class="avg-saving">'.$average.'%</span><p></p>';
    }
    return $price;//'Was:' . str_replace( '<ins>', ' Now:<ins>', $price );
}
?>