jQuery(document).ready(function($) {
	$(".et-social-icon a").attr('target', 'blank');
	if($(".cartlink").length){
		$("#top-header ul.et-social-icons").append('<li class="et-social-icon woocommerce-cart">'+$(".cartlink").html()+'</li>');
	}
	//console.log($(".second-sidebar > ul > li:nth-child(4)").html())
	//$(".dropdown-content").html();
	
	var count0 = $(".second-sidebar > ul > li:nth-child(3)").find("a").length;
	var html0 = "<option value='0'>Select Brands</option>";
	$(".second-sidebar > ul > li:nth-child(3)").find("a").each(function(i){
		//console.log(i,$(this).text(),$(this).attr('href'),$(this).next().text());
		html0+='<option value="'+$(this).attr('href')+'">'+$(this).text()+' '+$(this).next().text()+'</option>';
		if (i+1 === count0) {
        	$(".dropdown-content").html("<p>"+$(".second-sidebar > ul > li:nth-child(3)").find("h2").text()+'</p><select class="customfilter3">'+html0+'</select>');
    	}
	});
	
	var count1 = $(".second-sidebar > ul > li:nth-child(4)").find("a").length;
	var html1 = "<option value='0'>Select category</option>";
	$(".second-sidebar > ul > li:nth-child(4)").find("a").each(function(i){
		//console.log(i,$(this).text(),$(this).attr('href'),$(this).next().text());
		html1+='<option value="'+$(this).attr('href')+'">'+$(this).text()+' '+$(this).next().text()+'</option>';
		if (i+1 === count1) {
        	$(".dropdown-content").html($(".dropdown-content").html()+"<p>"+$(".second-sidebar > ul > li:nth-child(4)").find("h2").text()+'</p><select class="customfilter4">'+html1+'</select>');
    	}
	});
	$(document).on('change','select.customfilter3',function(){
		window.location = $(this).val();
	});
	$(document).on('change','select.customfilter4',function(){
		window.location = $(this).val();
	});
	$("body").on('click',".owl-stage-outer",function(event) {
		window.location="/shop";
	});
});